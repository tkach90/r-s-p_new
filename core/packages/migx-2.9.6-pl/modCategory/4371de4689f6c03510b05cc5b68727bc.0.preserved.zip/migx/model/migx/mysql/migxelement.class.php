<?php
require_once (dirname(dirname(__FILE__)) . '/migxelement.class.php');
class migxElement_mysql extends migxElement {}