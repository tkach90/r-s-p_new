tinyMCE.addI18n('te.modxlink',{
    link_desc:"Insert/edit link"
});