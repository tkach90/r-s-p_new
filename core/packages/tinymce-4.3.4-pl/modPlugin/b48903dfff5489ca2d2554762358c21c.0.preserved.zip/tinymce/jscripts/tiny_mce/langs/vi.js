tinyMCE.addI18n({vi:{
common:{
edit_confirm:"B\u1EA1n c\u00F3 mu\u1ED1n s\u1EED d\u1EE5ng ch\u1EBF \u0111\u1ED9 WYSIWYG cho textarea n\u00E0y?",
apply:"Thay \u0111\u1ED5i",
insert:"Th\u00EAm",
update:"C\u1EADp nh\u1EADt",
cancel:"H\u1EE7y b\u1ECF",
close:"Tho\u00E1t",
browse:"T\u00ECm",
class_name:"L\u1EDBp",
not_set:"-- Ch\u01B0a \u0111\u1EB7t --",
clipboard_msg:"Copy/Cut/Paste kh\u00F4ng \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3 trong tr\u00ECnh duy\u1EC7t web n\u00E0y.\nB\u1EA1n c\u00F3 mu\u1ED1n bi\u1EBFt th\u00EAm th\u00F4ng tin v\u1EC1 v\u1EA5n \u0111\u1EC1 n\u00E0y kh\u00F4ng??",
clipboard_no_support:"S\u1EED d\u1EE5ng ph\u00EDm t\u1EAFt kh\u00F4ng \u0111\u01B0\u1EE3c s\u1EED d\u1EE5ng trong tr\u00ECnh duy\u1EC7t hi\u1EC7n t\u1EA1i.",
popup_blocked:"Xin l\u1ED7i, Nh\u01B0ng ch\u1EBF \u0111\u1ED9 c\u1EEDa s\u1ED5 popup \u0111\u00E3 b\u1ECB v\u00F4 hi\u1EC7u ho\u00E1. B\u1EA1n s\u1EBD c\u1EA7n ph\u1EA3i t\u1EAFt ch\u1EE9c n\u0103ng ch\u1EB7n popup tr\u00EAn trang web n\u00E0y \u0111\u1EC3 s\u1EED d\u1EE5ng c\u00F4ng c\u1EE5 n\u00E0y ho\u00E0n to\u00E0n.",
invalid_data:"L\u1ED7i: Gi\u00E1 tr\u1ECB nh\u1EADp v\u00E0o kh\u00F4ng h\u1EE3p l\u1EC7. (\u0110\u01B0\u1EE3c \u0111\u00E1nh d\u1EA5u \u0111\u1ECF)",
more_colors:"M\u00E0u kh\u00E1c"
},
contextmenu:{
align:"Canh l\u1EC1",
left:"Tr\u00E1i",
center:"Gi\u1EEFa",
right:"Ph\u1EA3i",
full:"\u0110\u1EA7y"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"Ch\u00E8n ng\u00E0y",
inserttime_desc:"Ch\u00E8n gi\u1EDD",
months_long:"Th\u00E1ng M\u1ED9t,Th\u00E1ng Hai,Th\u00E1ng Ba,Th\u00E1ng T\u01B0,Th\u00E1ng N\u0103m,Th\u00E1ng S\u00E1u,Th\u00E1ng B\u1EA3y,Th\u00E1ng T\u00E1m,Th\u00E1ng Ch\u00EDn,Th\u00E1ng M\u01B0\u1EDDi,Th\u00E1ng M\u01B0\u1EDDi M\u1ED9t,Th\u00E1ng M\u01B0\u1EDDi Hai",
months_short:"Thg1,Thg2,Thg3,Thg4,Thg5,Thg6,Thg7,Thg8,Thg9,Th10,Th11,Th12",
day_long:"Ch\u1EE7 Nh\u1EADt,Th\u1EE9 Hai,Th\u1EE9 Ba,Th\u1EE9 T\u01B0,Th\u1EE9 N\u0103m,Th\u1EE9 S\u00E1u,Th\u1EE9 B\u1EA3y,Ch\u1EE7 Nh\u1EADt",
day_short:"CN,T2,T3,T4,T5,T6,T7,CN"
},
print:{
print_desc:"In"
},
preview:{
preview_desc:"Xem tr\u01B0\u1EDBc"
},
directionality:{
ltr_desc:"H\u01B0\u1EDBng tr\u00E1i qua ph\u1EA3i",
rtl_desc:"H\u01B0\u1EDBng ph\u1EA3i qua tr\u00E1i"
},
layer:{
insertlayer_desc:"Ch\u00E8n l\u1EDBp m\u1EDBi",
forward_desc:"Di chuy\u1EC3n v\u1EC1 tr\u01B0\u1EDBc",
backward_desc:"Di chuy\u1EC3n v\u1EC1 sau",
absolute_desc:"\u0110\u1EA3o v\u1ECB tr\u00ED c\u1ED1 \u0111\u1ECBnh",
content:"L\u1EDBp m\u1EDBi..."
},
save:{
save_desc:"L\u01B0u",
cancel_desc:"H\u1EE7y b\u1ECF t\u1EA5t c\u1EA3 thay \u0111\u1ED5i"
},
nonbreaking:{
nonbreaking_desc:"Ch\u00E8n k\u00FD t\u1EF1 kho\u1EA3ng c\u00E1ch kh\u00F4ng b\u1ECB ng\u1EAFt"
},
iespell:{
iespell_desc:"Ch\u1EA1y tr\u00ECnh ki\u1EC3m tra ch\u00EDnh t\u1EA3",
download:"ieSpell kh\u00F4ng \u0111\u01B0\u1EE3c ph\u00E1t hi\u1EC7n. B\u1EA1n c\u00F3 mu\u1ED1n c\u00E0i \u0111\u1EB7t n\u00F3 b\u00E2y gi\u1EDD?"
},
advhr:{
advhr_desc:"Th\u01B0\u1EDBc ngang"
},
emotions:{
emotions_desc:"Bi\u1EC3u T\u01B0\u1EE3ng C\u1EA3m X\u00FAc"
},
searchreplace:{
search_desc:"T\u00ECm",
replace_desc:"T\u00ECm/Thay th\u1EBF"
},
advimage:{
image_desc:"Ch\u00E8n/s\u1EEDa \u1EA3nh"
},
advlink:{
link_desc:"Th\u00EAm/S\u1EEDa Link"
},
xhtmlxtras:{
cite_desc:"Bi\u00EA\u0309u ch\u01B0\u01A1ng",
abbr_desc:"T\u00EAn vi\u1EBFt t\u1EAFt",
acronym_desc:"T\u1EEB vi\u1EBFt t\u1EAFt",
del_desc:"X\u00F3a",
ins_desc:"Ch\u00E8n",
attribs_desc:"Ch\u00E8n/S\u1EEDa c\u00E1c thu\u1ED9c t\u00EDnh"
},
style:{
desc:"S\u1EEDa ki\u1EC3u d\u00E1ng CSS"
},
paste:{
paste_text_desc:"D\u00E1nh nh\u01B0 Plain Text",
paste_word_desc:"D\u00E1n t\u1EEB Word",
selectall_desc:"Ch\u1ECDn t\u1EA5t",
plaintext_mode_sticky:"Paste is now in plain text mode. Click again to toggle back to regular paste mode. After you paste something you will be returned to regular paste mode.",
plaintext_mode:"Paste is now in plain text mode. Click again to toggle back to regular paste mode."
},
paste_dlg:{
text_title:"S\u1EED d\u1EE5ng CTRL+V tr\u00EAn b\u00E0n ph\u00EDm \u0111\u1EC3 d\u00E1n v\u0103n b\u1EA3n v\u00E0o c\u1EEDa s\u1ED5.",
text_linebreaks:"Gi\u1EEF ng\u1EAFt d\u00F2ng",
word_title:"S\u1EED d\u1EE5ng CTRL+V tr\u00EAn b\u00E0n ph\u00EDm \u0111\u1EC3 d\u00E1n v\u0103n b\u1EA3n v\u00E0o c\u1EEDa s\u1ED5."
},
table:{
desc:"Ch\u00E8n m\u1ED9t b\u1EA3ng m\u1EDBi",
row_before_desc:"Ch\u00E8n h\u00E0ng v\u00E0o tr\u01B0\u1EDBc",
row_after_desc:"Ch\u00E8n h\u00E0ng v\u00E0o sau",
delete_row_desc:"X\u00F3a d\u00F2ng",
col_before_desc:"Ch\u00E8n c\u1ED9t v\u00E0o tr\u01B0\u1EDBc",
col_after_desc:"Ch\u00E8n c\u1ED9t v\u00E0o sau",
delete_col_desc:"Lo\u1EA1i b\u1ECF c\u1ED9t",
split_cells_desc:"T\u00E1ch c\u00E1c \u00F4 \u0111\u00E3 k\u1EBFt h\u1EE3p c\u1EE7a b\u1EA3ng",
merge_cells_desc:"K\u1EBFt h\u1EE3p c\u00E1c \u00F4 c\u1EE7a b\u1EA3ng",
row_desc:"Thu\u1ED9c t\u00EDnh h\u00E0ng",
cell_desc:"Thu\u1ED9c t\u00EDnh \u00F4",
props_desc:"Thu\u1ED9c t\u00EDnh b\u1EA3ng",
paste_row_before_desc:"D\u00E1n hang v\u00E0o tr\u01B0\u1EDBc",
paste_row_after_desc:"D\u00E1n hang v\u00E0o sau",
cut_row_desc:"C\u1EAFt h\u00E0ng",
copy_row_desc:"Sao ch\u00E9p h\u00E0ng",
del:"X\u00F3a b\u1EA3ng",
row:"H\u00E0ng",
col:"C\u1ED9t",
cell:"\u00D4"
},
autosave:{
unload_msg:"Nh\u1EEFng thay \u0111\u1ED5i b\u1EA1n \u0111\u00E3 th\u1EF1c hi\u1EC7n s\u1EBD b\u1ECB m\u1EA5t n\u1EBFu b\u1EA1n \u0111i\u1EC1u h\u01B0\u1EDBng \u0111i t\u1EEB trang n\u00E0y.",
restore_content:"Kh\u00F4i ph\u1EE5c n\u1ED9i dung t\u1EF1 \u0111\u1ED9ng l\u01B0u l\u1EA1i.",
warning_message:"N\u1EBFu b\u1EA1n kh\u00F4i ph\u1EE5c l\u1EA1i n\u1ED9i dung \u0111\u00E3 l\u01B0u, b\u1EA1n s\u1EBD m\u1EA5t t\u1EA5t c\u1EA3 c\u00E1c n\u1ED9i dung m\u00E0 hi\u1EC7n \u0111ang trong tr\u00ECnh so\u1EA1n th\u1EA3o.\n\nB\u1EA1n c\u00F3 ch\u1EAFc l\u00E0 b\u1EA1n mu\u1ED1n kh\u00F4i ph\u1EE5c l\u1EA1i n\u1ED9i dung \u0111\u00E3 l\u01B0u?."
},
fullscreen:{
desc:"B\u1EADt/t\u1EAFt ch\u1EBF \u0111\u1ED9 to\u00E0n m\u00E0n h\u00ECnh"
},
media:{
desc:"Ch\u00E8n / s\u1EEDa ph\u01B0\u01A1ng ti\u1EC7n truy\u1EC1n th\u00F4ng nh\u00FAng",
edit:"S\u1EEDa ph\u01B0\u01A1ng ti\u1EC7n truy\u1EC1n th\u00F4ng nh\u00FAng"
},
fullpage:{
desc:"Thu\u1ED9c t\u00EDnh v\u0103n b\u1EA3n"
},
template:{
desc:"Ch\u00E8n m\u1ED9t n\u1ED9i dung m\u1EABu \u0111\u1ECBnh ngh\u0129a tr\u01B0\u1EDBc"
},
visualchars:{
desc:"B\u1EB7t/T\u1EAFt c\u00E1c k\u00FD t\u1EF1 \u0111i\u1EC1u khi\u1EC3n tr\u1EF1c quan."
},
spellchecker:{
desc:"B\u1EADt/T\u1EAFt ki\u1EC3m tra ch\u00EDnh t\u1EA3",
menu:"Thi\u1EBFt l\u1EADp ki\u1EC3m tra ch\u00EDnh t\u1EA3",
ignore_word:"B\u1ECF qua t\u1EEB ng\u1EEF",
ignore_words:"B\u1ECF qua t\u1EA5t c\u1EA3",
langs:"Ng\u00F4n ng\u1EEF",
wait:"Vui l\u00F2ng ch\u1EDD...",
sug:"G\u1EE3i \u00FD",
no_sug:"Kh\u00F4ng c\u00F3 g\u1EE3i \u00FD",
no_mpell:"Kh\u00F4ng c\u00F3 l\u1ED7i ch\u00EDnh t\u1EA3 \u0111\u01B0\u1EE3c t\u00ECm th\u1EA5y."
},
pagebreak:{
desc:"Ch\u00E8n ng\u1EAFt trang."
},
advlist:{
types:"Ki\u1EC3u",
def:"M\u1EB7c \u0111\u1ECBnh",
lower_alpha:"K\u00FD hi\u1EC7u alpha th\u01B0\u1EDDng",
lower_greek:"K\u00FD hi\u1EC7u Hy-l\u1EA1p th\u01B0\u1EDDng",
lower_roman:"K\u00FD hi\u1EC7u La m\u00E3 th\u01B0\u1EDDng",
upper_alpha:"K\u00FD hi\u1EC7u alpha cao",
upper_roman:"K\u00FD hi\u1EC7u La m\u00E3 hoa",
circle:"Tr\u00F2ng",
disc:"\u0110\u0129a",
square:"Vu\u00F4ng"
}}});