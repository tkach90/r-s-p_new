tinyMCE.addI18n('nn.modxlink',{
    link_desc:"Insert/edit link"
});